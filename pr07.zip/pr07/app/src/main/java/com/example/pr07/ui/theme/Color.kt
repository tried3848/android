package com.example.pr07.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)


@Immutable
data class CustomColors(
    val PrimaryColor: Color,
    val SecondaryColor: Color,
    val success: Color,
    val error: Color,
    val warning: Color,
    val inform: Color,
    val blackText1: Color,
    val blackText2: Color,
    val grayColor1: Color,
    val grayColor2: Color,
    val whiteColor: Color,
)

val LocalAppColors = staticCompositionLocalOf {
    CustomColors(
        PrimaryColor = Color.Unspecified,
        SecondaryColor = Color.Unspecified,
        success = Color.Unspecified,
        error = Color.Unspecified,
        warning = Color.Unspecified,
        inform = Color.Unspecified,
        blackText1 = Color.Unspecified,
        blackText2 = Color.Unspecified,
        grayColor1 = Color.Unspecified,
        grayColor2 = Color.Unspecified,
        whiteColor = Color.Unspecified

    )
}