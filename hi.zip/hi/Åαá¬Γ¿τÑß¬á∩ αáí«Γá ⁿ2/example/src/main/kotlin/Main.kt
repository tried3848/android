fun main(args: Array<String>) {
    val account = Account("Alexey", 100.00)
    account.deposit(1000.00)
    account.deposit(450.00)
    account.withdraw(150.00)
    val currentBalance = account.getBalance()
    println(account.getBalance())
}