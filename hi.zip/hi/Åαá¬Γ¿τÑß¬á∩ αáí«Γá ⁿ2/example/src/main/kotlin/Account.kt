class Account(val name: String, private var balance: Double) {
    fun deposit(amount: Double) {
        balance += amount
    }

    fun withdraw(amount: Double) {
        if (amount <= balance) {
            balance -= amount
        }
    }

    fun getBalance(): String {
        return "Ваш баланс: $balance"
    }
}